define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

  PageModule.prototype.showHide = function() {
    var x = document.getElementById("advancesearch").style.display;
    if (x === "none") {
      document.getElementById("advancesearch").style.display =
        "block";
    } else {
      document.getElementById("advancesearch").style.display =
        "none";
    }
  }


  return PageModule;
});
