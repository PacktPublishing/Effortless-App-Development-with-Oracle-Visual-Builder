define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

  PageModule.prototype.validateForm   = function(form) {
    var myformtracker = document.getElementById(form);
    if (myformtracker.valid === "valid") {
      return true;
    } else {
      myformtracker.showMessages();
      myformtracker.focusOn("@firstInvalidShown");
      return false;
    }
  }


  return PageModule;
});
