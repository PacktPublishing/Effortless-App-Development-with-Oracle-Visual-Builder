define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

  PageModule.prototype.settingLocale = function(currentLocale){
    if (currentLocale)  {
      window.localStorage.setItem('current.locale',currentLocale);
    }
  };


  return PageModule;
});
