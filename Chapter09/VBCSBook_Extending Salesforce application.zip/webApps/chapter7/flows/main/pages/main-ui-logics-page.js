define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

  PageModule.prototype.showHide = function() {
    var x = document.getElementById("advancesearch").style.display;
    if (x === "none") {
      document.getElementById("advancesearch").style.display =
        "block";
    } else {
      document.getElementById("advancesearch").style.display =
        "none";
    }
  }

PageModule.prototype.calculateAge = function(dateOfBirth)
  {
    var  currentDate = new Date();
    var birthDate = new Date(dateOfBirth);
    var totalAge = currentDate.getFullYear() - birthDate.getFullYear();
    var month = currentDate.getMonth() - birthDate.getMonth();
    if (month < 0 || (month === 0 && currentDate.getDate() < birthDate.getDate())) {
      totalAge--;
    }
    return totalAge;

  }


  return PageModule;
});
