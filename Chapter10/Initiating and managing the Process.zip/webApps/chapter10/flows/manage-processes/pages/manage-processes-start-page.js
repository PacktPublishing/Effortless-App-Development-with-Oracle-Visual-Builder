define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

  PageModule.prototype.convertToJson = function(data){
    var jsonArray = [];
    jsonArray = JSON.parse(data)
    return jsonArray;    
};


  return PageModule;
});
