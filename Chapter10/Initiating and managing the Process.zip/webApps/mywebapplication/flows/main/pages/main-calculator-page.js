define([], function() {
  'use strict';

  var PageModule = function PageModule() {};
  
  PageModule.prototype.calculate = function(number1,number2,op){
    if(op=="add"){
      return number1+number2;
    }
    
    else if(op=="sub"){
      return number1-number2;
    }
    
    else if(op=="mul"){
      return number1*number2;
    }
    
    else if(op=="div"){
      return number1/number2;
    }
  }

  return PageModule;
});
